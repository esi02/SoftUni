﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IBirthable
    {
        public string Birthdate { get; set; }
    }
}
